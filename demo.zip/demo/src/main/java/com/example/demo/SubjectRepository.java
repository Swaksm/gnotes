package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface SubjectRepository extends JpaRepository<Subject, Long> {

    // Ajoutez des méthodes personnalisées si nécessaire

    // Recherche une matière par son nom
    Subject findByName(String name);

    boolean existsByNameAndStudent(String subjectName, Student student);

    // Recherche toutes les matières d'un étudiant par son ID
    List<Subject> findByStudentId(Long studentId);

	Optional<Subject> findByIdAndStudentId(Long subjectId, Long id);
	void deleteByStudentId(Long studentId);
}
