package com.example.demo;

import org.springframework.http.HttpStatus;

public class EntityNotFoundException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private final HttpStatus httpStatus;
    private final String errorMessage;

    public EntityNotFoundException(String errorMessage, HttpStatus httpStatus) {
        super(errorMessage);
        this.errorMessage = errorMessage;
        this.httpStatus = httpStatus;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public int getHttpStatusCode() {
        return httpStatus.value();
    }
}
