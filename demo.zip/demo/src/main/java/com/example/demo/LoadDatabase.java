package com.example.demo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class LoadDatabase {

    private static final Logger log = LoggerFactory.getLogger(LoadDatabase.class);

    @Bean
    public CommandLineRunner initDatabase(
            StudentRepository studentRepository,
            SubjectRepository subjectRepository
    ) {
        return args -> {
            createStudentIfNotExists(studentRepository, "John Doe");
            createStudentIfNotExists(studentRepository, "Jane Doe");
            createStudentIfNotExists(studentRepository, "Alice Smith"); // Nouvel étudiant

            String[] predefinedSubjects = {"Mathématiques", "Français", "Histoire", "Physique", "Informatique"};

            for (Student student : studentRepository.findAll()) {
                for (String subjectName : predefinedSubjects) {
                    // Vérifier si la matière existe déjà pour cet étudiant
                    if (!subjectRepository.existsByNameAndStudent(subjectName, student)) {
                        Subject subject = new Subject();
                        subject.setName(subjectName);
                        subject.setCoefficient(generateRandomCoefficient());
                        subject.setStudent(student);

                        // Génération d'une note aléatoire entre 0 et 20 inclus (nombre entier)
                        int randomNote = (int) (Math.random() * 21);
                        subject.setNote(randomNote);

                        subjectRepository.save(subject);
                    }
                }
            }

            // Affichage des données dans les logs
            log.info("Students found with findAll():");
            log.info("-------------------------------");
            for (Student student : studentRepository.findAll()) {
                log.info(student.toString());
            }
            log.info("");

            log.info("Subjects found with findAll():");
            log.info("-------------------------------");
            for (Subject subject : subjectRepository.findAll()) {
                log.info(subject.toString());
            }
            log.info("");
        };
    }

    private void createStudentIfNotExists(StudentRepository studentRepository, String name) {
        List<Student> existingStudents = studentRepository.findByName(name);

        if (existingStudents.isEmpty()) {
            Student student = new Student();
            student.setName(name);
            studentRepository.save(student);
        }
    }

    private int generateRandomCoefficient() {
        // Générer un coefficient aléatoire entre 1 et 5 inclus
        return (int) (Math.random() * 5) + 1;
    }
}


