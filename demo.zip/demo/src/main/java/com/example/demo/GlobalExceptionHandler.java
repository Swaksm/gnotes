package com.example.demo;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(EntityNotFoundException.class)
    public ResponseEntity<String> handleEntityNotFoundException(EntityNotFoundException ex) {
        String responseBody = "Error: " + ex.getErrorMessage() + " (HTTP " + ex.getHttpStatus() + ")";
        return ResponseEntity.status(ex.getHttpStatus().value()).body(responseBody);
    }

    @ExceptionHandler(InvalidRequestException.class)
    public ResponseEntity<String> handleInvalidRequestException(InvalidRequestException ex) {
        String responseBody = "Error: " + ex.getMessage() + " (HTTP " + ex.getHttpStatus() + ")";
        return ResponseEntity.status(ex.getHttpStatus().value()).body(responseBody);
    }

    // Ajoutez d'autres gestionnaires d'exceptions au besoin

    @ExceptionHandler(Exception.class)
    public ResponseEntity<String> handleGenericException(Exception ex, WebRequest request) {
        String responseBody = "An unexpected error occurred: " + ex.getMessage();
        return ResponseEntity.status(500).body(responseBody);
    }
}
