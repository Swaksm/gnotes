package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/students")
public class StudentController {

    @Autowired
    private StudentRepository studentRepository;
    @Autowired
    private SubjectRepository subjectRepository;
    @GetMapping
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    
    
    @GetMapping("/{id}")
    public ResponseEntity<Student> getStudentById(@PathVariable Long id) {
        return studentRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElseThrow(() -> new EntityNotFoundException("Student not found with id: " + id, HttpStatus.NOT_FOUND));
    }
    
    

    @GetMapping("/{studentId}/subjects/{subjectId}")
    public ResponseEntity<Subject> getSubjectById(@PathVariable Long studentId, @PathVariable Long subjectId) {
        if (!studentRepository.existsById(studentId)) {
            throw new EntityNotFoundException("Student not found with id: " + studentId, HttpStatus.NOT_FOUND);
        }
        Subject subject = subjectRepository.findById(subjectId)
                .orElseThrow(() -> new EntityNotFoundException("Subject not found with id: " + subjectId, HttpStatus.NOT_FOUND));
        if (!subject.getStudent().getId().equals(studentId)) {
            throw new EntityNotFoundException("Subject not found for student with id: " + studentId, HttpStatus.NOT_FOUND);
        }
        return ResponseEntity.ok(subject);
    }

    
    
    @GetMapping("/{id}/subjects")
    public ResponseEntity<List<Subject>> getSubjectsByStudentId(@PathVariable Long id) {
        if (!studentRepository.existsById(id)) {
            throw new EntityNotFoundException("Student not found with id: " + id, HttpStatus.NOT_FOUND);
        }
        List<Subject> subjects = subjectRepository.findByStudentId(id);
        return ResponseEntity.ok(subjects);
    }

    
    
    
    @GetMapping("/{id}/average")
    //pour test curl -X GET -H "Content-Type: application/json" http://localhost:8080/students/1/average
    public ResponseEntity<Double> getStudentAverage(@PathVariable Long id) {
        if (!studentRepository.existsById(id)) {
            throw new EntityNotFoundException("Student not found with id: " + id, HttpStatus.NOT_FOUND);
        }
        List<Subject> subjects = subjectRepository.findByStudentId(id);
        if (subjects.isEmpty()) {
            return ResponseEntity.ok(0.0);  // Return 0.0 if no subjects found
        }
        double totalWeightedScore = 0.0;
        double totalCoefficient = 0.0;
        for (Subject subject : subjects) {
            totalWeightedScore += subject.getNote() * subject.getCoefficient();
            totalCoefficient += subject.getCoefficient();
        }
        double average = totalWeightedScore / totalCoefficient;
        return ResponseEntity.ok(average);
    }
    
    
    
    @GetMapping("/all-averages")
  //curl -X GET -H "Content-Type: application/json" http://localhost:8080/students/all-averages
    public ResponseEntity<List<Double>> getAllAverages() {
        List<Student> students = studentRepository.findAll();
        List<Double> averages = new ArrayList<>();

        for (Student student : students) {
            averages.add(getStudentAverage(student.getId()).getBody());
        }
        return ResponseEntity.ok(averages);
    }

    
    
    @PostMapping
    //curl -X POST -H "Content-Type: application/json" -d "{\"name\":\"Matthieu\"}" http://localhost:8080/students
    public ResponseEntity<Student> createStudent(@RequestBody Student newStudent) {
        Student savedStudent = studentRepository.save(newStudent);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedStudent);
    }


    
    
    
    
    @PutMapping("/{id}")
  //curl -X PUT -H "Content-Type: application/json" -d "{\"name\": \"robin\"}" http://localhost:8080/students/id
    public ResponseEntity<String> updateOrCreateStudent(@PathVariable Long id, @RequestBody Student updatedStudent) {
        if (studentRepository.existsById(id)) {
            Student existingStudent = studentRepository.findById(id).orElseThrow();
            String oldName = existingStudent.getName();
            existingStudent.setName(updatedStudent.getName());
            Student savedStudent = studentRepository.save(existingStudent);
            String message = "L'étudiant avec l'ID " + id + " a été mis à jour avec succès. Nom précédent : " + oldName + ", Nouveau nom : " + savedStudent.getName();
            return ResponseEntity.ok().body(message);
        } else {
            updatedStudent.setId(id);
            Student savedStudent = studentRepository.save(updatedStudent);
            String message = "L'étudiant avec l'ID " + id + " a été créé avec succès. Nouveau nom : " + savedStudent.getName();
            return ResponseEntity.status(HttpStatus.CREATED).body(message);
        }
    }

    @DeleteMapping("/{id}")
    void deleteEtudiant(@PathVariable int id) {
        studentRepository.deleteById((long) id);
    }




    
}
