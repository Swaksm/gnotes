package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/subjects")
public class SubjectController {
	
    @Autowired
    private SubjectRepository subjectRepository;
    
    
    
    @GetMapping
    public List<Subject> getAllSubjects() {
        return subjectRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Subject> getSubjectById(@PathVariable Long id) {
        Optional<Subject> subject = subjectRepository.findById(id);
        return subject.map(ResponseEntity::ok)
                .orElseThrow(() -> new EntityNotFoundException("Subject not found with id: " + id, HttpStatus.NOT_FOUND));
    }

    @GetMapping("/a") // Exemple d'URL non valide
    public ResponseEntity<Void> handleInvalidUrl() {
        throw new InvalidRequestException("Invalid URL", HttpStatus.NOT_FOUND);
    }

    @GetMapping("/error") // Exemple d'URL non valide sans ID
    public ResponseEntity<Void> handleMissingId() {
        throw new InvalidRequestException("Missing ID in the URL", HttpStatus.NOT_FOUND);
    }

    @PostMapping
    public ResponseEntity<Subject> createSubject(@RequestBody Subject subject) {
        Subject savedSubject = subjectRepository.save(subject);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedSubject);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Subject> updateSubject(@PathVariable Long id, @RequestBody Subject updatedSubject) {
        if (!subjectRepository.existsById(id)) {
            throw new EntityNotFoundException("Subject not found with id: " + id, HttpStatus.NOT_FOUND);
        }

        updatedSubject.setId(id);
        Subject savedSubject = subjectRepository.save(updatedSubject);
        return ResponseEntity.ok(savedSubject);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSubject(@PathVariable Long id) {
        if (!subjectRepository.existsById(id)) {
            throw new EntityNotFoundException("Subject not found with id: " + id, HttpStatus.NOT_FOUND);
        }

        subjectRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
    
    //curl -X DELETE -H "Content-Type: application/json" http://localhost:8080/subjects/{id}

}
