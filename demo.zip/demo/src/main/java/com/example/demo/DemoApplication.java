package com.example.demo;

import java.io.File;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoApplication implements ApplicationRunner {

    public static void main(String[] args) {
        executeScript();
        SpringApplication.run(DemoApplication.class, args);
    }

    @Override
    public void run(ApplicationArguments args) throws Exception {
        // Code à exécuter après le démarrage de l'application
    }

    private static void executeScript() {
        try {
            // Obtenez le chemin absolu du script kill_port8080
            String scriptPath = new File("src/main/resources/kill_port8080.bat").getAbsolutePath();

            // Exécutez le script avec le chemin absolu
            Process process = Runtime.getRuntime().exec("cmd /c start " + scriptPath);

            // Attendre que le processus se termine
            int exitCode = process.waitFor();

            // Afficher le code de sortie (0 signifie une exécution réussie)
            System.out.println("Script exit code: " + exitCode);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
