creer la base demo2

CREATE TABLE IF NOT EXISTS `student` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

CREATE TABLE IF NOT EXISTS `subject` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE latin1_bin DEFAULT NULL,
  `coefficient` double NOT NULL,
  `note` double NOT NULL,
  `student_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `c` (`student_id`),
  CONSTRAINT `FK966amhbdgsgjsy3uqfhfim5mt` FOREIGN KEY (`student_id`) REFERENCES `student` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=644 DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

CREATE USER 'test'@'localhost' IDENTIFIED BY '';
GRANT ALL PRIVILEGES ON demo2.* TO 'test'@'localhost';
FLUSH PRIVILEGES;


-- Supprimer toutes les données de la table "subject"
DELETE FROM demo2.subject;

-- Supprimer toutes les données de la table "student"
DELETE FROM demo2.student;

-- Ajouter la contrainte FOREIGN KEY avec ON DELETE CASCADE
ALTER TABLE subject
ADD CONSTRAINT fk_student_id
FOREIGN KEY (student_id)
REFERENCES student(id)
ON DELETE CASCADE;
